// src/app/user.service.ts
import { Injectable } from '@angular/core';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private users: User[] = [
    { ZID: 'Z0235551', EMPLOYEE_NAME: 'Avinash Birudugadda', EMPLOYEE_DIVISION: 'DIWIA14' },
    { ZID: 'Z0147130', EMPLOYEE_NAME: 'Rahul Gowtham Sangani', EMPLOYEE_DIVISION: 'DIWIA14' },
    { ZID: 'Z0088735', EMPLOYEE_NAME: 'Divya Namala', EMPLOYEE_DIVISION: 'DIWIA14' },
    { ZID: 'Z0002065', EMPLOYEE_NAME: 'Pradeep Thonduru', EMPLOYEE_DIVISION: 'DIWIA15' },

  ];

  getUsers(): User[] {
    return this.users;
  }

  getUserById(zid: string ): User | undefined {
    return this.users.find((user) => user.ZID === zid);
  }

  addUser(user: User): void {
    this.users.push(user);
  }

  updateUser(user: User): void {
    const index = this.users.findIndex((u) => u.ZID === user.ZID);
    if (index !== -1) {
      this.users[index] = user;
    }
  }

  deleteUser(id: string): void {
    this.users = this.users.filter((user) => user.ZID !== id);
  }
}
