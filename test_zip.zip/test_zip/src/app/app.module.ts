// app.module.ts
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserAddComponent } from './user-add/user-add.component';
import { UserEditComponent } from './user-edit/user-edit.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  imports: [
    FormsModule,
    RouterModule.forRoot([]),
    AppRoutingModule
  ],
  declarations: [
    UserListComponent,
    UserDetailsComponent,
    UserAddComponent,
    UserEditComponent
  ],
})
export class AppModule { }
