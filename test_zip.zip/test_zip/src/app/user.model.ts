
export interface User {
    ZID: string;
    EMPLOYEE_NAME: string;
    EMPLOYEE_EMAIL: string;
  }
  