// src/app/user-add/user-add.component.ts
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css'],
})
export class UserAddComponent {
  userForm: FormGroup;

  constructor(private fb: FormBuilder, private userService: UserService, private router: Router) {
    this.userForm = this.fb.group({
      ZID: ['', Validators.required],
      EMPLOYEE_NAME: ['', Validators.required],
      EMPLOYEE_EMAIL: ['', [Validators.required, Validators.email]],
    });
  }

  saveUser(): void {
    const newUser = this.userForm.value;
    this.userService.addUser(newUser);
    this.router.navigate(['/users']);
  }
}
