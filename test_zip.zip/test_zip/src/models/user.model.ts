
export interface User {
    ZID: string;
    EMPLOYEE_NAME: string;
    EMPLOYEE_DIVISION: string;
  }
  